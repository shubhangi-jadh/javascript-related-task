function swap()
{
    var a=5,b=10;

    document.getElementById("result1").value= b;
    document.getElementById("answer2").value= a;
    }