
function myFunction()
 {
      var text = document.getElementById("uppercase").innerHTML;
      document.getElementById("uppercase").innerHTML = text.toUpperCase();
  }