function onButtonClick()
{
    alert("Welcome");

    var name = document.getElementById("firstname").value;

    var password = document.getElementsByClassName("password").value;
    alert(name);
    alert(password);
}
